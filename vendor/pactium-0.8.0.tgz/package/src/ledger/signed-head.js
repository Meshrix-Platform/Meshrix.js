import crypto from "node:crypto";

import { PACTIUM_PROTOCOL, PACTIUM_SCHEMA_VERSION } from "../protocol/constants.js";
import { canonicalEncode, normalizeCanonicalValue } from "../canonical/value.js";
import { createId, protocolHash } from "../protocol/hashing.js";
import { asArray, asRecord, nowIso, safeText } from "../shared/records.js";
import { createVerificationFailure } from "../verification/failure.js";
import { verifyLedgerConsistencyProof } from "./transparency-log.js";

export function createVerifierManifest(input = {}) {
  const payload = {
    protocol: PACTIUM_PROTOCOL,
    schema: PACTIUM_SCHEMA_VERSION,
    manifestType: "pactium.verifier-manifest",
    signers: asArray(input.signers).map((signer) => ({
      signerId: safeText(signer.signerId),
      algorithm: safeText(signer.algorithm, "ed25519"),
      publicKey: safeText(signer.publicKey),
      validFrom: safeText(signer.validFrom),
      validTo: safeText(signer.validTo),
      revokedAt: safeText(signer.revokedAt),
      revocationReason: safeText(signer.revocationReason),
      roles: asArray(signer.roles).map(String)
    })).filter((signer) => signer.signerId && signer.publicKey),
    revokedSigners: asArray(input.revokedSigners).map((revocation) => ({
      signerId: safeText(typeof revocation === "string" ? revocation : revocation.signerId),
      revokedAt: safeText(revocation.revokedAt),
      reason: safeText(revocation.reason ?? revocation.revocationReason)
    })).filter((revocation) => revocation.signerId),
    quorum: Math.max(1, Number(input.quorum ?? input.quorumPolicy?.ledgerHead ?? 1)),
    quorumPolicy: normalizeCanonicalValue(asRecord(input.quorumPolicy)),
    witnesses: asArray(input.witnesses).map((witness) => ({
      witnessId: safeText(witness.witnessId ?? witness.signerId),
      algorithm: safeText(witness.algorithm, "ed25519"),
      publicKey: safeText(witness.publicKey),
      roles: asArray(witness.roles).map(String)
    })).filter((witness) => witness.witnessId && witness.publicKey),
    publicCheckpoint: normalizeCanonicalValue(asRecord(input.publicCheckpoint)),
    gossip: normalizeCanonicalValue(asRecord(input.gossip))
  };
  return {
    ...payload,
    manifestId: input.manifestId || createId("verifier_manifest", payload),
    manifestHash: protocolHash("verifier.manifest", payload)
  };
}

export function ledgerHeadSigningPayload(head = {}) {
  return normalizeCanonicalValue({
    protocol: PACTIUM_PROTOCOL,
    schema: PACTIUM_SCHEMA_VERSION,
    ledgerId: head.ledgerId || "pactium-operation-ledger",
    size: Number(head.size || 0),
    rootHash: safeText(head.rootHash),
    root: safeText(head.root),
    headId: safeText(head.headId),
    previousHeadId: safeText(head.previousHeadId),
    createdAt: safeText(head.createdAt)
  });
}

export function signLedgerHead(head = {}, {
  privateKey = "",
  signerId = "",
  manifest = null,
  createdAt = nowIso()
} = {}) {
  const resolvedManifest = manifest ? createVerifierManifest(manifest) : null;
  const payload = ledgerHeadSigningPayload(head);
  const signature = crypto.sign(null, Buffer.from(canonicalEncode(payload)), privateKey).toString("base64");
  return {
    protocol: PACTIUM_PROTOCOL,
    schema: PACTIUM_SCHEMA_VERSION,
    signatureType: "pactium.ledger-head-signature",
    signerId: safeText(signerId),
    algorithm: "ed25519",
    manifestId: resolvedManifest ? resolvedManifest.manifestId : safeText(manifest?.manifestId),
    manifestHash: resolvedManifest ? resolvedManifest.manifestHash : safeText(manifest?.manifestHash),
    headId: safeText(head.headId),
    signedPayloadHash: protocolHash("ledger.head.signing", payload),
    signature,
    createdAt
  };
}

export function verifyLedgerHeadSignature(head = {}, manifest = {}, options = {}) {
  const verifierManifest = manifest?.manifestType === "pactium.verifier-manifest"
    ? manifest
    : createVerifierManifest(manifest);
  const signatures = asArray(options.signatures ?? head.signatures ?? (head.signature ? [head.signature] : []));
  const failures = [];
  let accepted = 0;
  const acceptedSigners = new Set();
  const payload = ledgerHeadSigningPayload(head);
  const payloadBytes = Buffer.from(canonicalEncode(payload));
  const signedPayloadHash = protocolHash("ledger.head.signing", payload);
  const signersById = new Map();
  for (const signer of asArray(verifierManifest.signers)) {
    if (signer?.signerId && !signersById.has(signer.signerId)) signersById.set(signer.signerId, signer);
  }
  const revokedSignersById = new Map();
  for (const revocation of asArray(verifierManifest.revokedSigners)) {
    if (revocation?.signerId && !revokedSignersById.has(revocation.signerId)) {
      revokedSignersById.set(revocation.signerId, revocation);
    }
  }
  for (const signature of signatures) {
    const record = asRecord(signature);
    const signer = signersById.get(record.signerId);
    if (!signer) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "unknown_signer",
        evidenceRef: safeText(record.signerId)
      }));
      continue;
    }
    if (record.manifestId && record.manifestId !== verifierManifest.manifestId) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "signature_manifest_mismatch",
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (record.manifestHash && record.manifestHash !== verifierManifest.manifestHash) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "signature_manifest_mismatch",
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (acceptedSigners.has(record.signerId)) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "duplicate_signature_signer",
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (signer.algorithm !== "ed25519" || record.algorithm !== "ed25519") {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "unsupported_signature_algorithm",
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (!asArray(signer.roles).includes("ledger-head")) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "signer_role_missing",
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (record.signedPayloadHash !== signedPayloadHash) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "bad_signed_head_payload",
        evidenceRef: record.signerId
      }));
      continue;
    }
    const sigTime = safeText(record.createdAt ?? head.createdAt);
    const revokedRecord = revokedSignersById.get(record.signerId);
    if (signer.revokedAt || revokedRecord) {
      const revokedAt = safeText(signer.revokedAt ?? revokedRecord?.revokedAt ?? sigTime);
      if (!revokedAt || sigTime >= revokedAt) {
        failures.push(createVerificationFailure({
          layer: "ledger-head-signature",
          code: "signer_revoked",
          message: `Signer ${record.signerId} is revoked.`,
          evidenceRef: record.signerId,
          details: {
            revokedAt,
            reason: signer.revocationReason ?? revokedRecord?.reason ?? ""
          }
        }));
        continue;
      }
    }
    if (signer.validFrom && sigTime < signer.validFrom) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "signer_not_yet_valid",
        message: `Signer ${record.signerId} is not yet valid (validFrom: ${signer.validFrom}).`,
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (signer.validTo && sigTime > signer.validTo) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "signer_expired",
        message: `Signer ${record.signerId} has expired (validTo: ${signer.validTo}).`,
        evidenceRef: record.signerId
      }));
      continue;
    }
    let ok = false;
    try {
      ok = crypto.verify(
        null,
        payloadBytes,
        signer.publicKey,
        Buffer.from(String(record.signature), "base64")
      );
    } catch (error) {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "bad_signer_public_key",
        message: error instanceof Error ? error.message : "Signer public key could not be used for verification.",
        evidenceRef: record.signerId
      }));
      continue;
    }
    if (ok) {
      accepted += 1;
      acceptedSigners.add(record.signerId);
    }
    else {
      failures.push(createVerificationFailure({
        layer: "ledger-head-signature",
        code: "bad_head_signature",
        evidenceRef: record.signerId
      }));
    }
  }
  if (accepted < Number(verifierManifest.quorum)) {
    failures.push(createVerificationFailure({
      layer: "ledger-head-signature",
      code: "manifest_quorum_not_met",
      details: { accepted, quorum: verifierManifest.quorum }
    }));
  }
  return {
    protocol: PACTIUM_PROTOCOL,
    ok: failures.length === 0,
    accepted,
    failures
  };
}

export function advanceTrustedHead({
  oldHead = {},
  newHead = {},
  proof = {},
  manifest = null,
  trustedManifest = null,
  signatures = []
} = {}) {
  const failures = [];
  if (!verifyLedgerConsistencyProof({ oldHead, newHead, proof })) {
    failures.push(createVerificationFailure({
      layer: "trusted-head",
      code: "bad_trusted_head_consistency",
      message: "New Ledger head does not extend the old trusted head."
    }));
  }
  // Only trust explicitly provided manifests, not the head's self-carried manifest.
  const verificationManifest = trustedManifest || manifest || null;
  if (verificationManifest) {
    const signatureResult = verifyLedgerHeadSignature(newHead, verificationManifest, { signatures });
    failures.push(...signatureResult.failures);
  }
  if (failures.length > 0) {
    return { protocol: PACTIUM_PROTOCOL, ok: false, failures };
  }
  return {
    protocol: PACTIUM_PROTOCOL,
    ok: true,
    trustStoreType: "pactium.trusted-head-store",
    ledgerId: newHead.ledgerId || oldHead.ledgerId || "pactium-operation-ledger",
    lastTrustedHead: newHead,
    verifierManifestRef: manifest?.manifestId || "",
    updatedAt: nowIso(),
    failures: []
  };
}
