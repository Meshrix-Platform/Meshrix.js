export type PactiumCanonicalValue =
  | null
  | boolean
  | number
  | string
  | PactiumCanonicalValue[]
  | { [key: string]: PactiumCanonicalValue };

export type PactiumRecord = Record<string, unknown>;

export interface PactiumDataDirOptions {
  dataDir?: string;
  userDataPath?: string;
  inMemory?: boolean;
  storageBackend?: "json" | "sqlite" | "auto" | string;
  databasePath?: string;
  includeSystemSqliteDetection?: boolean;
  sqliteDetectionTimeoutMs?: number;
}

export interface PactiumStoragePort {
  protocol: string;
  schema: string;
  dataDir: string;
  inMemory: boolean;
  storageBackend?: string;
  selectedStorageBackend?: string;
  sqlitePath?: string;
  sqliteProvider?: string;
  storageFormat?: string;
  atomicTransactions?: boolean;
  initialize(): Promise<void>;
  close(): Promise<void>;
  putBlock(value: unknown, options?: PactiumRecord): Promise<PactiumRecord>;
  getBlock(cid: string): Promise<(PactiumRecord & { bytes?: Uint8Array }) | null>;
  hasBlock(cid: string): Promise<boolean>;
  walk(rootCid: string): Promise<PactiumRecord>;
  putProtocolObject(scope: string, key: string, value: unknown): Promise<PactiumCanonicalValue>;
  getProtocolObject(scope: string, key: string, fallback?: unknown): Promise<unknown>;
  deleteProtocolObject?(scope: string, key: string): Promise<void>;
  listProtocolObjectKeys?(scope: string): Promise<string[]>;
  scanBlocks?(options?: {
    afterCid?: string;
    limit?: number;
    kinds?: string[];
  }): Promise<{ supported: boolean; items: PactiumRecord[]; nextCursor: string; done: boolean }>;
  collectGarbage?(options?: {
    roots?: string[];
    retain?: string[];
    sweepKinds?: string[];
    createdBefore?: string;
    dryRun?: boolean;
  }): Promise<PactiumRecord>;
  reclaimDatabasePages?(options?: { pages?: number }): Promise<PactiumRecord>;
  clearCache?(): void;
  withWriteLock?<T>(
    task: () => T | Promise<T>,
    options?: { name?: string; timeoutMs?: number; retryMs?: number; staleMs?: number }
  ): Promise<T>;
  pruneBlocks?(predicate?: (record: PactiumRecord) => boolean): number;
  pruneProtocolObjects?(predicate?: (record: PactiumRecord & { scope: string; key: string; value: unknown }) => boolean): number;
}

export interface PactiumLedgerHead {
  protocol: string;
  schema: string;
  size: number;
  rootHash: string;
  root: string;
  headId?: string;
  previousHeadId?: string;
  createdAt?: string;
  signatureRef?: string;
  signatureHash?: string;
  verifierManifest?: PactiumRecord;
  verifierManifestRef?: string;
  signatures?: PactiumRecord[];
}

export interface PactiumProofEnvelope {
  protocol: string;
  schema: string;
  envelopeType: "pactium.proof-envelope";
  envelopeKind: string;
  envelopeId: string;
  factType: string;
  factId: string;
  factRef: PactiumRecord;
  ledgerHead: PactiumLedgerHead;
  proofRefs: PactiumRecord[];
  extensions: PactiumRecord[];
  criticalExtensions: string[];
  relatedEnvelopeIds: string[];
  replayed: boolean;
  disposition?: "recorded" | "replayed";
  createdAt: string;
}

export interface PactiumVerificationFailure {
  protocol: string;
  layer: string;
  code: string;
  severity: string;
  message?: string;
  evidenceRef?: string;
  repairable?: boolean;
  details?: PactiumRecord;
}

export interface PactiumVerificationResult {
  protocol: string;
  ok: boolean;
  envelopeId?: string;
  proofStructurallyValid?: boolean;
  ledgerHeadSignatureValid?: boolean;
  ledgerHeadTrusted?: boolean;
  trustedSignatureValid?: boolean;
  trustPolicy?: string;
  failures: PactiumVerificationFailure[];
  /** Non-fatal warnings (e.g. proofSizeWarning, incomplete rebuild). */
  warnings?: PactiumVerificationFailure[];
  checked?: string[];
}

export interface PactiumProofBundle {
  protocol: string;
  schema: string;
  bundleType: "pactium.proof-bundle.indexed";
  manifest: PactiumRecord;
  envelope: PactiumProofEnvelope;
  index?: PactiumRecord[];
  blocksEncoding?: string;
  binaryBase64?: string;
  byteLength?: number;
  bundleHash: string;
}

export interface PactiumIndexScanOptions extends PactiumRecord {
  min?: string;
  max?: string;
  limit?: number;
  after?: string;
}

export interface PactiumProofOptions {
  /** Maximum number of leaf entries allowed in a proof. Exceeding this produces a proofSizeWarning. */
  maxProofLeafEntries?: number;
  /** Maximum proof size in bytes. Exceeding this produces a proofSizeWarning. */
  maxProofBytes?: number;
  /** If true, proofSizeWarning becomes a hard failure. Default false. */
  failOnProofSizeWarning?: boolean;
  /** For write APIs with stateMutations, emit per-key proofs for every mutation instead of the default bounded sample. */
  stateMutationProofMode?: "sampled" | "full";
}

export interface PactiumProofVerificationOptions extends PactiumProofOptions {
  supportedCriticalExtensions?: string[];
  proofVerifiers?: PactiumRecord;
  requireAllProofs?: boolean;
  verifierManifest?: PactiumRecord;
  trustedManifest?: PactiumRecord;
  ledgerHeadSignatures?: PactiumRecord[];
  trustPolicy?: "structural" | "self-carried-manifest" | "trusted-manifest-required" | string;
  requireFullStateMutationProofs?: boolean;
}

export interface PactiumIndexProofContext extends PactiumRecord {
  proofMaterial?: PactiumRecord;
}

export interface PactiumIndexEngine {
  protocol: string;
  engine: string;
  domain: string;
  createIndex(entries?: PactiumRecord[], options?: PactiumRecord): Promise<PactiumRecord>;
  put(root: string, key: string, value: unknown, options?: PactiumRecord): Promise<PactiumRecord>;
  delete(root: string, key: string, options?: PactiumRecord): Promise<PactiumRecord>;
  mutate(root: string, mutations?: PactiumRecord[], options?: PactiumRecord): Promise<PactiumRecord>;
  get(root: string, key: string): Promise<PactiumRecord | null>;
  prove(root: string, key: string, options?: PactiumProofOptions): Promise<PactiumRecord>;
  proveMembershipMultiproof(root: string, keys?: string[], options?: PactiumProofOptions): Promise<PactiumRecord>;
  proveRange(root: string, options?: PactiumIndexScanOptions): Promise<PactiumRecord>;
  verifyProof(proof: PactiumRecord, context?: PactiumIndexProofContext): boolean;
  scan(root: string, options?: PactiumIndexScanOptions): Promise<PactiumRecord[]>;
  prefix(root: string, keyPrefix?: string, options?: PactiumIndexScanOptions): Promise<PactiumRecord[]>;
  diff(leftRoot: string, rightRoot: string): Promise<PactiumRecord[]>;
  readSnapshot(root: string): Promise<PactiumRecord>;
  readIndexRoot(root: string): Promise<PactiumRecord>;
  readNode(root: string): Promise<PactiumRecord>;
}

export interface PactiumLedgerPageOptions extends PactiumRecord {
  start?: number;
  limit?: number;
}

export interface PactiumLedgerPage extends PactiumRecord {
  protocol: string;
  start: number;
  limit: number;
  entries: PactiumRecord[];
  nextPosition: number;
  head: PactiumLedgerHead;
}

export interface PactiumLedger extends PactiumRecord {
  append(entry?: PactiumRecord): Promise<PactiumRecord>;
  appendBatch(entries?: PactiumRecord[], options?: PactiumRecord): Promise<PactiumRecord>;
  head(): Promise<PactiumLedgerHead>;
  entries(): Promise<PactiumRecord[]>;
  pageEntries(options?: PactiumLedgerPageOptions): Promise<PactiumLedgerPage>;
}

export interface PactiumProofBundleVerificationResult extends PactiumVerificationResult {
  bundleHash?: string;
  envelope?: PactiumVerificationResult;
}

export interface PactiumProofBundleVerificationOptions extends PactiumRecord {
  verifyAllBlocks?: boolean;
  maxBundleBytes?: number;
  allowTrailingBytes?: boolean;
  maxHeaderSize?: number;
  maxBlockSize?: number;
  trustPolicy?: string;
  trustedManifest?: PactiumRecord;
  /** Require full (non-sampled) state mutation proofs. Default false. When false, large mutations use sampled proofs. */
  requireFullStateMutationProofs?: boolean;
  /** Maximum leaf entries per proof before emitting a proofSizeWarning. */
  maxProofLeafEntries?: number;
  /** Maximum proof size in bytes before emitting a proofSizeWarning. */
  maxProofBytes?: number;
  /** If true, proofSizeWarning becomes a hard failure. Default false. */
  failOnProofSizeWarning?: boolean;
}

export interface PactiumProofBundleExportOptions extends PactiumRecord {
  format?: "indexed";
}

export interface PactiumCore {
  protocol: string;
  schema: string;
  dataDir: string;
  beginOperationIntent(input?: PactiumRecord): Promise<PactiumProofEnvelope>;
  appendOperationOutcome(input?: PactiumRecord): Promise<PactiumProofEnvelope>;
  recordOperationReceipt(input?: PactiumRecord & {
    profile?: "receipt" | "on-change";
    changeKey?: string;
    changeDigest?: string;
    finalizeEnvelopeExtensions?: ((envelope: PactiumProofEnvelope) => unknown | Promise<unknown>) | null;
  }): Promise<(PactiumProofEnvelope & { disposition: "recorded" | "replayed" }) | (PactiumRecord & {
    disposition: "unchanged";
    envelopeId: string;
    receiptId: string;
  })>;
  recordOperation(input?: PactiumRecord): Promise<PactiumProofEnvelope>;
  recordOperations(inputs?: PactiumRecord[]): Promise<PactiumRecord & { envelopes: PactiumProofEnvelope[] }>;
  lookupOpenIntent(intentId: string): Promise<PactiumRecord>;
  lookupOutcome(intentId: string): Promise<PactiumRecord>;
  lookupReceipt(receiptId: string): Promise<PactiumRecord>;
  createAppendCondition(input?: PactiumRecord): PactiumRecord;
  getLedgerCursor(input?: PactiumRecord): Promise<PactiumRecord>;
  getWorkspaceCursor(input?: PactiumRecord & {
    workspaceId?: string;
    fromCursor?: PactiumRecord | null;
    position?: number;
    limit?: number;
    proofOptions?: PactiumProofOptions;
  }): Promise<PactiumRecord>;
  verifyCursor(cursor: PactiumRecord, context?: PactiumRecord): boolean;
  advanceTrustedHead(input?: PactiumRecord): PactiumRecord;
  planRecovery(input?: PactiumRecord): PactiumRecord;
  getWorkspaceProjection(workspaceId?: string, options?: PactiumRecord & { limit?: number }): Promise<PactiumRecord>;
  proveWorkspaceMembership(input?: PactiumRecord & {
    workspaceId?: string;
    ledgerEventId?: string;
    proofOptions?: PactiumProofOptions;
  }): Promise<PactiumRecord>;
  verifyEnvelope(
    envelope: PactiumProofEnvelope,
    options?: PactiumProofVerificationOptions
  ): Promise<PactiumVerificationResult>;
  exportProofBundle(envelopeOrId: PactiumProofEnvelope | string, options?: PactiumProofBundleExportOptions): Promise<PactiumProofBundle>;
  createExtension(extension: PactiumRecord): Promise<PactiumRecord>;
  storeEnvelope(envelope: PactiumProofEnvelope): Promise<PactiumProofEnvelope>;
  protocolCatalog(): Promise<PactiumRecord>;
  /** Run integrity checks. Pass { rebuild: true } to replay ledger and compare derived roots. */
  doctor(options?: { rebuild?: boolean }): Promise<PactiumRecord & {
    ok: boolean; dataDir: string; ledgerSize: number;
    rebuild?: { attempted: boolean; comparableRootsCount: number; mismatches: PactiumRecord[]; stateRebuildIncomplete: boolean; warnings: PactiumVerificationFailure[] };
  }>;
  /**
   * Preview or execute conservative mark/sweep of obsolete derived index nodes.
   * Durable stores default to dry-run; page reclamation is opt-in.
   */
  compactStorage(options?: {
    dryRun?: boolean;
    reclaimPages?: number;
  }): Promise<PactiumRecord>;
  /** Resolve a CAS block by CID. Returns a canonical clone — safe for external mutation. */
  resolveBlock(cid: string): Promise<(PactiumRecord & { bytes?: Uint8Array }) | null>;
  /** Check whether a CAS block exists. */
  hasBlock(cid: string): Promise<boolean>;
  /** Read the current ledger head, or a specific head by ID. */
  readLedgerHead(id?: string): Promise<PactiumLedgerHead | null>;
  /** Read a ledger leaf by index. */
  readLedgerLeaf(index: number): Promise<PactiumRecord | null>;
  /** Read a protocol object. Returns a canonical clone. */
  readProtocolObject(scope: string, key: string, fallback?: unknown): Promise<unknown>;
  /** List all keys in a protocol object scope. */
  listProtocolObjectKeys(scope: string): Promise<string[]>;
  /** Serialize a compound mutation through the core lane and owned storage transaction. */
  withMutationTransaction<T>(task: () => T | Promise<T>): Promise<T>;
  close(): Promise<void>;
}

export interface PactiumHttpServerOptions extends PactiumDataDirOptions {
  pactium?: PactiumCore | null;
  maxBodyBytes?: number;
  /** Enable mutation routes (POST/PUT/DELETE). Default false. */
  enableMutations?: boolean;
  /** Authorization hook for mutation routes. Return false or { allowed: false } to reject. */
  authorize?: ((ctx: { method: string; pathname: string; capability: string; headers: Record<string, string | string[] | undefined> }) => boolean | { allowed: boolean; reason?: string; statusCode?: number } | Promise<boolean | { allowed: boolean; reason?: string; statusCode?: number }>) | null;
}

export interface PactiumHttpServerStartOptions extends PactiumDataDirOptions {
  host?: string;
  port?: number | string;
  maxBodyBytes?: number;
  /** Enable mutation routes (POST/PUT/DELETE). Default false. */
  enableMutations?: boolean;
  authorize?: PactiumHttpServerOptions["authorize"];
}

export interface PactiumHttpServerStartResult {
  protocol: "pactium.v0.3.http";
  server: unknown;
  host: string;
  port: number;
  maxBodyBytes: number;
  url: string;
}

export const PACTIUM_PROTOCOL: "pactium.v0.3";
export const PACTIUM_SCHEMA_VERSION: "pactium.v0.3.schema.latest";
export const PACTIUM_PACKAGE_VERSION: "0.8.0";
export const PACTIUM_HTTP_PROTOCOL: "pactium.v0.3.http";
export const PACTIUM_HTTP_MAX_BODY_BYTES: 1048576;
export const PACTIUM_INDEX_ENGINE: "pactium.verifiable-index-engine";
export const PACTIUM_INDEX_SPLITTER: "pactium-cdc-boundary";
export const PACTIUM_PROOF_BUNDLE_TYPE: "pactium.proof-bundle.indexed";
export const PACTIUM_BUNDLE_ENCODING: "pactium.bundle.indexed-record-stream";
export const PACTIUM_PROOF_TYPES: Readonly<{
  ledgerInclusion: "ledger.inclusion.audit-path";
  ledgerConsistency: "ledger.consistency.audit-path";
  indexMembership: "index.membership.prolly-path";
  indexMembershipMultiproof: "index.membership-multiproof.prolly-paths";
  indexRange: "index.range.prolly-paths";
  indexNonMembership: "index.non-membership.compact-prolly-boundary";
}>;
export const PACTIUM_TRUST_POLICIES: Readonly<{
  structural: "structural";
  selfCarriedManifest: "self-carried-manifest";
  trustedManifestRequired: "trusted-manifest-required";
}>;
export const PACTIUM_PROTOCOL_PROFILE: PactiumRecord;
export const HASH_DOMAINS: Record<string, string>;

export function defaultPactiumDataDir(): string;
export function resolveDataDir(dataDir?: string): string;
export function resolveWithin(root: string, ...segments: string[]): string;
export function normalizeCanonicalValue(value: unknown): PactiumCanonicalValue;
export function canonicalString(value: unknown): string;
export function canonicalEncode(value: unknown): Uint8Array;
export function canonicalDecode(bytes: Uint8Array | ArrayBuffer | string): PactiumCanonicalValue;
export function toCanonicalSafeValue(
  value: unknown,
  options?: {
    maxDepth?: number;
    maxArrayItems?: number;
    maxObjectKeys?: number;
    maxStringLength?: number;
    binaryMode?: "summary" | "preserve" | string;
  },
  depth?: number
): unknown;
export interface PactiumWeightedLruCache<Key = unknown, Value = unknown> {
  readonly size: number;
  readonly weight: number;
  has(key: Key): boolean;
  get(key: Key): Value | undefined;
  set(key: Key, value: Value, explicitWeight?: number): Value;
  delete(key: Key): boolean;
  clear(): void;
  keys(): IterableIterator<Key>;
}
export function createWeightedLruCache<Key = unknown, Value = unknown>(options?: {
  maxEntries?: number;
  maxWeight?: number;
  weightOf?: (value: Value, key: Key) => number;
}): PactiumWeightedLruCache<Key, Value>;
export function protocolHashHex(domain: string, value: unknown): string;
export function protocolHash(domain: string, value: unknown): string;
export function cidForBytes(bytes: Uint8Array | ArrayBuffer | string): string;
export function cidForCanonical(value: unknown): string;
export function createVerificationFailure(input?: PactiumRecord): PactiumVerificationFailure;
export function createStoragePort(options?: PactiumDataDirOptions): PactiumStoragePort;
export function createJsonStoragePort(options?: PactiumDataDirOptions): PactiumStoragePort;
export function createSqliteStoragePort(options?: PactiumDataDirOptions): PactiumStoragePort;
export function detectSqliteCapabilities(options?: PactiumRecord): Promise<PactiumRecord>;
export function sqliteStorageAvailable(options?: PactiumRecord): boolean;
export const PACTIUM_MANIFEST_FILE: "pactium-manifest.json";
export const PACTIUM_SQLITE_FILE: "pactium.sqlite";
export const PROTOCOL_STORAGE_CATEGORY: "protocol-substrate";
export function classifyProtocolStorageArtifact(relativePath?: string): string;
export function inspectDataDir(input?: {
  dataDir?: string;
  userDataPath?: string;
}): {
  ok: boolean;
  dataDir: string;
  protocol: string;
  schema: string;
  packageVersion: string;
  findings: PactiumRecord[];
};
export function assertCurrentDataDir(input?: {
  dataDir?: string;
  userDataPath?: string;
}): {
  ok: boolean;
  dataDir: string;
  protocol: string;
  schema: string;
  packageVersion: string;
  findings: PactiumRecord[];
};
export function createContentAddressedStore(options: {
  storage: PactiumStoragePort;
  defaultKind?: string;
  defaultCodec?: string;
  pinScope?: string;
}): PactiumRecord;
export function createAppendOnlyEventLog(options: {
  storage: PactiumStoragePort;
  protocolObjectScope?: string;
  hashDomain?: string;
  createEventId?: (input: PactiumRecord) => string;
  withWriteLock?: (task: () => unknown, options?: PactiumRecord) => Promise<unknown>;
  segmentSize?: number;
  maxSegmentBytes?: number;
}): PactiumRecord;
export function createStateCommitStore(options: {
  storage: PactiumStoragePort;
  core: PactiumCore;
  indexEngine: PactiumIndexEngine;
  eventLog?: PactiumRecord;
  scopes?: {
    stateRoot?: string;
    stateCommit?: string;
    stateCommitEventIndex?: string;
    stateMutationIdempotency?: string;
    eventLog?: string;
  };
  hashDomainPrefix?: string;
  eventHashDomain?: string;
  createCommitId?: (input: PactiumRecord) => string;
  createEventId?: (input: PactiumRecord) => string;
  defaultCommitOperationId?: string;
  defaultRestoreOperationId?: string;
  withTransaction?: (task: () => unknown, options?: PactiumRecord) => Promise<unknown>;
}): PactiumRecord;
export function ledgerLeafHash(leaf: unknown): string;
export function ledgerNodeHash(leftHash: string, rightHash: string): string;
export function emptyTreeHash(): string;
export function createCompactRange(input?: PactiumRecord): PactiumRecord;
export function createLedgerInclusionProof(input?: PactiumRecord): PactiumRecord;
export function verifyLedgerInclusionProof(input?: PactiumRecord): boolean;
export function createLedgerConsistencyProof(input?: PactiumRecord): PactiumRecord;
export function verifyLedgerConsistencyProof(input?: PactiumRecord): boolean;
export function createLedgerTransparencyLog(options?: PactiumRecord): PactiumLedger;
export function createVerifierManifest(input?: PactiumRecord): PactiumRecord;
export function ledgerHeadSigningPayload(head?: PactiumRecord): PactiumRecord;
export function signLedgerHead(head?: PactiumRecord, options?: PactiumRecord): PactiumRecord;
export function verifyLedgerHeadSignature(head?: PactiumRecord, manifest?: PactiumRecord, options?: PactiumRecord): PactiumVerificationResult & { accepted?: number };
export function advanceTrustedHead(input?: PactiumRecord): PactiumRecord;
export function createVerifiableIndexEngine(options?: PactiumRecord): PactiumIndexEngine;
export function verifyIndexProof(proof: PactiumRecord, context?: PactiumIndexProofContext): boolean;
export function createAppendCondition(input?: PactiumRecord): PactiumRecord;
export function createTrackingCursor(input?: PactiumRecord): PactiumRecord;
export function covers(cursor: PactiumRecord, position: number): boolean;
export function advanceTo(cursor: PactiumRecord, position: number, options?: PactiumRecord): PactiumRecord;
export function samePositionAs(left: PactiumRecord, right: PactiumRecord): boolean;
export function verifyTrackingCursor(cursor: PactiumRecord, context?: PactiumRecord): boolean;
export function createPactium(options?: PactiumDataDirOptions & { storage?: PactiumStoragePort | null }): PactiumCore;
export function verifyProofEnvelope(envelope: PactiumProofEnvelope, options?: PactiumProofVerificationOptions): Promise<PactiumVerificationResult>;
export function verifyProofBundle(bundle: PactiumProofBundle, options?: PactiumProofBundleVerificationOptions): Promise<PactiumProofBundleVerificationResult>;
export function createDefaultProofVerifierRegistry(extraVerifiers?: PactiumRecord): Map<string, (...args: unknown[]) => unknown>;
export function createRepairPlanner(): PactiumRecord;
export function createMaintenanceTaskEngine(options?: PactiumRecord): PactiumRecord;
export function runPactiumQualityGateProfile(options?: PactiumRecord): Promise<PactiumRecord>;
export function createPactiumHttpServer(options?: PactiumHttpServerOptions): unknown;
export function startPactiumHttpServer(options?: PactiumHttpServerStartOptions): Promise<PactiumHttpServerStartResult>;
