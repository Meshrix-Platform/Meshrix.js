# Frequently Asked Questions

## General

### What is Pactium?

Pactium is a host-neutral proof-first protocol substrate for Node.js. It records operation facts into an append-only transparency log and produces cryptographic proofs that operations were recorded and the ledger history is consistent.

### What does "proof-first" mean?

Every write operation returns a verifiable proof envelope rather than a simple acknowledgment. The proof is the API response -- it includes ledger inclusion proofs, index proofs, and content-addressed references that can be independently verified.

### Is Pactium a database?

No. Pactium is a protocol substrate that records operation metadata and produces cryptographic proofs. It maintains verifiable indexes and state roots, but it is not a general-purpose data store. Host systems own their application data, business logic, and side effects.

### Is Pactium a blockchain?

No. Pactium is a local protocol substrate, not a distributed consensus system. It uses a transparency log (similar to Certificate Transparency) for append-only operation recording and Merkle proofs for verification, but it does not run a network, perform consensus, or require gas/tokens.

### What is the relationship between Pactium and Meshrix?

Meshrix is an independent downstream framework that uses the public `pactium` package. Pactium owns generic facts and proofs; Meshrix owns governance, policy, permissions, services, plugins, effects, and operations. Pactium has no Meshrix-specific package entry point or product mode.

---

## Installation and Setup

### Why does Pactium require Node.js 22+?

Pactium uses modern Node.js APIs (built-in test runner, structured clone, modern crypto) that are stable in Node.js 22 LTS. It also supports Node.js 24 for forward compatibility.

### I get `ERR_REQUIRE_ESM` -- what do I do?

Pactium is a pure ESM package. It cannot be loaded with `require()`. Options:

1. Add `"type": "module"` to your `package.json`
2. Rename your file to `.mjs`
3. Use dynamic import: `const { createPactium } = await import("pactium")`

### Does Pactium have any runtime dependencies?

Pactium declares zero runtime dependencies. Core proof functionality uses Node.js built-in modules. The SQLite backend can also use a host-provided optional npm `better-sqlite3` package when present; Pactium does not install it as a dependency.

### Where does Pactium store data?

By default, Pactium stores data in the directory you specify via `dataDir` option (e.g., `./.pactium`) with `storageBackend: "auto"`. Auto mode chooses SQLite for new data directories when a supported provider is available (`node:sqlite` or optional npm `better-sqlite3`), otherwise JSON. Use `inMemory: true` for tests and `storageBackend: "json"` for local/debug profiles that explicitly want file-per-object storage. Storage is managed through the Storage Port abstraction.

---

## Usage

### How do I record an operation?

```js
import { createPactium } from "pactium";

const pactium = createPactium({ dataDir: "./.pactium" });

const envelope = await pactium.recordOperation({
  operationId: "my.operation",
  workspaceId: "my-workspace",
  idempotencyKey: "unique-intent-key",
  outcomeIdempotencyKey: "unique-outcome-key",
  input: { /* your operation input */ },
  stateMutations: [
    { key: "state-key", value: { /* your state */ } }
  ]
});
```

### What happens if I record the same operation twice?

If you use the same `idempotencyKey`, Pactium returns an Idempotency Replay -- the existing proof envelope is returned without appending a new ledger fact. The replay is marked so callers can distinguish it from a new commit.

### How do I verify a proof?

```js
// Local verification (requires Pactium instance)
const result = await pactium.verifyEnvelope(envelope);

// Portable verification (no local storage needed)
import { verifyProofBundle } from "pactium";
const bundle = await pactium.exportProofBundle(envelope);
const result = await verifyProofBundle(bundle);
```

### What is a Proof Bundle and when should I use it?

A Proof Bundle is a portable, self-contained export that includes all content-addressed blocks needed for verification. Use it when:

- You need to verify a proof without access to the original Pactium storage
- You want to share verification material with external parties
- You want to archive proof material independently from the data directory
- You need to preserve verification capability across Pactium version upgrades

### What is the difference between Intent and Outcome?

- **Operation Intent** declares what the host intends to do (recorded before the operation)
- **Operation Outcome** declares the result (recorded after the operation completes or fails)

Both are append-only facts. The Intent is never mutated into the Outcome. Failed and successful outcomes are both recorded as facts.

### Can I use Pactium without Meshrix?

Yes. Pactium is independently usable by any host that needs verifiable operation recording.

### Does Pactium store my input and result values?

Not by default. Operation facts store `inputHash` and `resultHash`. A `stateMutations` value is explicitly persisted as state, and a Proof Extension `value` is explicitly persisted as portable proof content. The host must minimize and authorize both before supplying them.

---

## Architecture

### Why is there only one Verifiable Index Engine?

Pactium uses a shared Canonical Prolly Tree-based engine for all indexes (state, workspace, lifecycle, idempotency, causality). Domain adapters convert domain-specific material into canonical keys and values. This eliminates the complexity of maintaining multiple independent tree implementations while keeping proofs consistent.

### Why are hash algorithms and chunking not configurable?

These are protocol constants, not tuning options. If a verifier expects `sha256` and the writer used `sha3`, proofs would be incompatible. Protocol parameters are fixed per protocol version to ensure all parties can verify proofs without negotiation.

### What does the host system own vs. what does Pactium own?

**Pactium owns:** Protocol facts, canonical encoding, hash computation, ledger ordering, index proofs, verification, proof generation, repair planning.

**Host owns:** Policy decisions (allow/deny), operation dispatching, side-effect execution, authorization, durable evidence storage, UI, key management and rotation.

### Does Workspace Projection provide isolation?

No. Pactium maintains verifiable order and membership projections for each `workspaceId`. These prove logical membership in a projection; authentication, authorization, tenant separation, storage isolation, and access control remain host-owned.

---

## Verification

### What does verification actually check?

Envelope verification checks:

1. Ledger inclusion proof validity (leaf is in the ledger at the stated tree size)
2. Content-addressed proof material integrity (referenced blocks match their CIDs)
3. Index proof validity (state/workspace proofs are mathematically correct)
4. Critical extension support (all required extensions are understood)
5. Signed Ledger Head validity when verifier manifest material is present (default core recording signs heads unless unsigned mode is explicit)

### What is a "critical extension"?

A critical extension is a Proof Extension that must be understood by the verifier. If a verifier encounters an unknown critical extension, verification fails. Hosts define extension names and verifier support; Pactium does not assign business meaning to them.

### What happens when verification fails?

Pactium returns structured Verification Failures (not thrown exceptions). Each failure includes:

- `layer` -- which verification layer failed (ledger, index, envelope, extension)
- `code` -- machine-readable failure code
- `severity` -- critical, warning, or info
- `repairable` -- whether the Repair Planner can address it

You can feed failures to the Repair Planner to generate deterministic repair tasks.

---

## Troubleshooting

### "Storage not initialized" error

Call `createPactium()` or `createStoragePort()` with a valid `dataDir`. The data directory is created automatically on first use.

### Verification returns unexpected failures

- Ensure you're verifying against the same Pactium instance (or use Proof Bundles for portable verification)
- Check that proof material refs are resolvable (content-addressed blocks exist in storage)
- Ensure the verifier explicitly supports every host-defined critical extension

### Proof Bundle verification fails but envelope verification passes

This usually means the bundle export is incomplete. Ensure `exportProofBundle()` was called with a valid envelope and that the bundle contains all required content-addressed blocks.

### "Consistency proof failed" between two ledger heads

This means the ledger history diverged -- a later ledger state is not a valid continuation of the earlier one. This is a security-critical finding that indicates the ledger was rewritten or forked.

### Performance concerns with large indexes

The Prolly Tree engine uses structural sharing and Content-Defined Chunking for efficient updates. For large state sets, consider:

- Using the `scan()` and `prefix()` methods for range queries instead of full snapshots
- Using `diff()` to compute changes between state roots with the shared-node diff API
- Checking memory usage with the pressure profile: `PACTIUM_FULL_PRESSURE=1 npm run verify:protocol:gates`

### What trust policies does Pactium support?

Pactium supports three trust policies via the `trustPolicy` option on `verifyEnvelope()` and `verifyProofBundle()`:

| Mode | Behavior |
| --- | --- |
| `structural` (least trust) | Verifies proof structure only. Skips all signature verification. |
| `self-carried-manifest` | Verifies proof structure + validates signatures against the manifest embedded in the proof material. Does **not** require a caller-supplied trusted manifest. `ledgerHeadTrusted` is always `false`. This is the default only for in-memory/development verification. |
| `trusted-manifest-required` (most trust) | Requires a caller-supplied `trustedManifest`. Verifies proof structure + validates signatures against the trusted manifest. `ledgerHeadTrusted` can be `true`. |

A **self-carried manifest** (embedded in the proof) is NOT a trusted manifest. It provides format-level signature validation but not trust. Only a caller-supplied `trustedManifest` establishes trust.

Persistent storage and Proof Bundle verification default to `trusted-manifest-required`. Production callers should pass a trusted manifest, rotate or revoke signers in the manifest, and use quorum/witness policies appropriate for their deployment.

### What is the difference between full and sampled state mutation proofs?

State mutation proofs use **sampled mode** by default when there are more than 32 unique touched keys. In sampled mode, the **first 32 unique touched keys in canonical key order** are proven. If the same key appears more than once in one state commit, Pactium records the final net effect for that key and uses the last mutation for that key. Set `proofOptions.stateMutationProofMode: "full"` when recording the operation to emit an individual proof for every unique touched key. Set `requireFullStateMutationProofs: true` when verifying an envelope or Proof Bundle to reject sampled proof material.

### Does the local JSON backend provide ACID transactions?

No. The local JSON backend uses **write-ahead commit markers** (pending/complete) with `doctor()` diagnostics for crash detection. This is a WAL marker + diagnostic pattern, not an ACID database transaction.

**Commit marker coverage boundaries:**
- Commit markers currently cover operation lifecycle commits only: `beginOperationIntent`, `appendOperationOutcome`, and `recordOperation` (which combines both).
- Materialization/cache operations (`exportProofBundle`, `storeEnvelope`, `createExtension`) may write storage or runtime-state but are not covered by lifecycle commit markers.
- The local JSON backend remains a WAL-marker + diagnostic pattern, not ACID.

For production deployments requiring local durable transactions, use the SQLite backend. The JSON backend is appropriate for local development, low-concurrency use, and debugging. Distributed multi-node production still requires an external consistency layer.

### Are proofs constant-size (bounded)?

No. The `maxProofLeafEntries` and `maxProofBytes` options are **size guards**, not a bounded proof format. They produce `proofSizeWarning` when limits are exceeded. By default this is a non-fatal warning. Set `failOnProofSizeWarning: true` for hard failures. Use membership multiproofs and range proofs when many related keys need smaller aggregate proof material.

### Is the index engine a fully optimized Prolly Tree?

The index engine uses content-addressed Prolly nodes with full path-copying mutations. `put`, `delete`, and `mutate` rewrite only the affected leaf path and necessary ancestors, while `diff()` skips equal subtree roots and handles non-aligned child ranges. The engine intentionally keeps Pactium's protocol-defined splitter and proof format rather than adopting Dolt's storage engine.

For current throughput characteristics, run the pressure profile: `PACTIUM_FULL_PRESSURE=1 npm run verify:protocol:gates`.
